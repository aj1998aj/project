package javaapplication3;
import java.sql.*;
import javax.swing.*;
import java.util.Scanner;
public class test 
{
    private static final String username = "root";
    private static final String password = "ajy-1998";
    private static final String connn_String = "jdbc:mysql://127.0.0.1:3306/DB";
    
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner (System.in);
        
        Connection conn = null;
        
        try {
            conn = DriverManager.getConnection(connn_String, username, password);
            System.out.println("connected!!!");  
            Statement stmt= (Statement) conn.createStatement();
            System.out.print("ENTER THE USER NAME : ");
            String user = sc.next() ;
            System.out.print("ENTER THE PASSWORD : ");
            String pass=sc.next();
            String insert = "INSERT INTO info (user,password) VALUES (?,?)";
            PreparedStatement pst= conn.prepareStatement(insert);
            
               stmt.executeUpdate(insert);
               stmt.execute(insert);
               stmt.executeQuery(insert);
        }catch (SQLException e) {
           System.err.println(e);
        }
        
        
    }
}
